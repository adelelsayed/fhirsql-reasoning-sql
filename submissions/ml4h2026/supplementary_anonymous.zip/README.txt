Supplementary material -- anonymized for double-blind review
============================================================

Contents

  scripts/     corpus generation, execution-verification, and the two analysis
               scripts that reproduce the paper's tables:
                 analyze_unseen_failures.py           -> Section 6 failure table
                 analyze_unseen_discriminativeness.py -> the 53.9% collision bound
  schema/      the frozen benchmark schema injected into every prompt, plus the
               valuesets DDL fragment used only in the ablation
  results/     every per-seed training log, held-out evaluation summary, failure
               log, and ablation leg behind the numbers in the paper
  *.ipynb      the supervised fine-tuning, reinforcement learning, and ablation
               notebooks, configured as run

Not included, to preserve anonymity: the paper, README, license, citation
metadata, and model card, all of which name the author or link to public
repositories. The generated datasets (~86 MB) and the DuckDB databases are
omitted for size; they are regenerable from scripts/ and will be linked in the
camera-ready version.

Absolute paths have been replaced with <PROJECT_ROOT>.

Reproducing the analysis tables requires only the committed logs:
    cd scripts && python analyze_unseen_failures.py
    cd scripts && python analyze_unseen_discriminativeness.py   (needs heldout.duckdb)
